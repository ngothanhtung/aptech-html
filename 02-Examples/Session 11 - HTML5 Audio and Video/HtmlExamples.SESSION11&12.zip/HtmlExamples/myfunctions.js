/**
 * Created by user on 4/25/15.
 */
function hello() {

    alert("XIN CHAO HTML5");

}